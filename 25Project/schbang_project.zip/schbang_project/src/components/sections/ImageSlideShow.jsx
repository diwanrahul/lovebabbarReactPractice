import React from 'react';
// import './ImageSlideShow.css'; // Import the CSS file

const ImageSlideShow = () => {
  return (
    <div  className='h-screen relative bg-white'>
      <div className='box'>
        <figure className='figure'>
          {/* Image is handled by CSS pseudo-elements */}
        </figure>
      </div>
    </div>
  );
}

export default ImageSlideShow;
