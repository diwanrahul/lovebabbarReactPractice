import React from 'react'

const Privacypolicy = () => {
  return (
    <div>Privacypolicy</div>
  )
}

export default Privacypolicy