import React from 'react'

const About = () => {
  return (
    <div className='h-screen'>About</div>
  )
}

export default About